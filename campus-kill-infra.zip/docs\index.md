# 校园杀手游基础架构文档

## 系统总览

校园杀是一款多人在线卡牌对战手游，采用三套游戏引擎 + 三套UI引擎的异构架构设计。

## 子系统文档索引

### 提示词库

| 子系统 | 文件 | 描述 |
|--------|------|------|
| FairyGUI集成 | `prompts/01-engine/01-FairyGUI-Integration.md` | FairyGUI编辑器与Unity对接 |
| Unity双引擎 | `prompts/01-engine/08-Unity-DualEngine.md` | Unity 2D/3D双模式切换 |
| 核心玩法 | `prompts/03-gameplay/03-Card-Game-Core.md` | 卡牌对战核心逻辑 |
| 网络联机 | `prompts/03-gameplay/04-Networking-Multiplayer.md` | Photon/Mirror联机方案 |
| 后端服务 | `prompts/05-ops/05-Backend-Server.md` | FastAPI后端架构 |
| 移动构建 | `prompts/04-build/07-Mobile-Build.md` | Android/iOS构建配置 |
| 质量门禁 | `prompts/06-quality/09-Quality-Gate.md` | 自动化质量检查 |
| CI/CD | `prompts/06-quality/14-Testing-CICD.md` | 持续集成部署 |
| 运维监控 | `prompts/05-ops/15-Ops-Monitoring.md` | ELK+Grafana监控栈 |
| 整合主控 | `prompts/07-master/16-Integration-Master.md` | 全系统集成方案 |
| 技术栈全景 | `prompts/07-master/17-Tech-Stack-Master.md` | 14引擎+18运维系统全景 |
| 分类库 | `prompts/07-master/18-Card-Classification-Library.md` | 卡牌分类库设计 |

### 自动化脚本

| 脚本 | 功能 | 状态 |
|------|------|------|
| `install-all.bat` | 一键安装全部依赖 | ✅ |
| `install-python-deps.ps1` | Python pytest/requests/rich | ✅ |
| `install-node-deps.ps1` | Vite/Capacitor/Vitest | ✅ |
| `install-ops-monitoring.ps1` | Docker+ELK+Grafana | ⚠️ 需Docker Desktop |
| `verify-unity-modules.ps1` | Unity模块完整性 | ✅ |
| `auto-fairygui-publish.py` | FairyGUI自动发布 | ✅ |
| `auto-ui-visual-test.py` | UI视觉回归测试 | ✅ |
| `auto-design-system-checker.py` | 设计系统合规检查 | ✅ |
| `auto-pipeline.bat` | 全流水线调度 | ✅ |

### 代码库

| 文件 | 描述 |
|------|------|
| `codebase/BuildScript.cs` | Unity自动化构建脚本（BuildPipeline） |
| `campus_kill.py` | Python 3原生控制台版（1129行全规则实现） |

## 数据流

```
卡牌分类库 (JSON)
    ├──→ Unity CardData.cs (C# 自动生成)
    ├──→ Python card_loader.py (JSON加载器)
    └──→ Web card-data.ts (TypeScript接口)
                ↓
         三套游戏引擎
                ↓
         三套UI引擎渲染
```

## 运维拓扑

```
Git Push → GitHub Actions
    ├──→ Pytest (Python测试)
    ├──→ Vitest (Node测试)
    ├──→ Unity Build (Android + WebGL)
    └──→ Docker Build & Push
              ↓
        Docker Compose 部署
              ↓
    ┌──── ELK (日志) ────┐
    ├── Grafana (面板) ──┤
    ├── Loki (聚合) ─────┤
    └── Prometheus (指标) ┘
```

## 版本历史

- v1.0.0 (2026-07-27): 初始发布，32份提示词 + 10个自动化脚本 + 卡牌分类库 + 运维引擎
