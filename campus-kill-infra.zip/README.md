# 校园杀 Campus Kill - 手游全自动基础架构

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Unity](https://img.shields.io/badge/Unity-2022.3.62f3c1-black.svg)](https://unity.com)
[![Python](https://img.shields.io/badge/Python-3.11%2B-blue.svg)](https://python.org)
[![Node](https://img.shields.io/badge/Node-24%2B-green.svg)](https://nodejs.org)

一键式全自动手游基础架构搭建工具包。为卡牌对战手游提供完整的**引擎栈、UI栈、配置体系、CI/CD流水线、运维监控**脚手架。

## 特性

- **3套游戏引擎**：Unity 2022.3 / Python 3 控制台 / H5 + Capacitor
- **3套UI引擎**：FairyGUI / UGUI Canvas 2D / HTML + CSS
- **卡牌分类库**：30张卡牌 × 23角色 × 37技能 × 5阵营，纯JSON零依赖
- **全自动脚本**：Python/Node/Unity/Docker 一键安装与环境验证
- **运维引擎**：GitHub Actions + Docker + ELK + Grafana + Loki + Prometheus
- **质量门禁**：所有提示词内置 verification-modal.html 验证弹窗

## 快速开始

### 1. 克隆仓库

```bash
git clone https://github.com/YOUR_USERNAME/campus-kill-infra.git
cd campus-kill-infra
```

### 2. 安装依赖

```bat
scripts\install\install-all.bat
```

### 3. 验证环境

```powershell
scripts\install\verify-unity-modules.ps1
```

### 4. 加载 Claude Skill

将 `skill/SKILL.md` 导入 Claude Code，然后：

```
@Marvis 帮我搭建手游基础架构，目标平台 Android+WebGL
```

## 目录结构

```
campus-kill-infra/
├── prompts/                  # AI提示词库（按子系统分类，32份）
│   ├── 01-engine/            # 引擎集成
│   ├── 02-ui/                # UI引擎
│   ├── 03-gameplay/          # 核心玩法
│   ├── 04-build/             # 构建打包
│   ├── 05-ops/               # 运维部署
│   ├── 06-quality/           # 质量门禁
│   └── 07-master/            # 整合主控
├── config/                   # 手游配置体系
│   ├── card-library/         # 卡牌分类库（5个JSON）
│   ├── design-tokens/        # 设计Token
│   └── build-profiles/       # 构建配置
├── scripts/                  # 自动化脚本
│   ├── install/              # 环境安装
│   ├── build/                # 构建
│   ├── test/                 # 测试
│   ├── automation/           # UI自动化
│   └── ops/                  # 运维
├── engine-plugins/           # 引擎插件包
│   ├── unity/
│   └── fairygui/
├── codebase/                 # 核心代码
├── verification/             # 验证门禁
├── skill/                    # Claude Code Skill 定义
│   └── SKILL.md
└── docs/                     # 文档
```

## 技术栈

| 层级 | 技术选型 |
|------|---------|
| 游戏引擎 | Unity 2022.3 / Python 3 控制台 / H5+Capacitor |
| UI引擎 | FairyGUI / UGUI Canvas 2D / HTML+CSS |
| 渲染 | URP (Universal Render Pipeline) |
| 音频 | FMOD / Unity Audio Mixer |
| 物理 | Unity Physics 2D |
| 数据 | JSON 纯文本分类库 |
| 网络 | Photon / Mirror / WebSocket |
| 后端 | Python FastAPI + PostgreSQL + Redis |
| CI/CD | GitHub Actions |
| 容器化 | Docker + Docker Compose |
| 监控 | ELK + Grafana + Loki + Prometheus |
| 测试 | Pytest + Vitest + Unity Test Framework |

## 构建目标

| 平台 | 产出格式 | 目标大小 |
|------|---------|---------|
| Android | APK | ≥ 1GB |
| iOS | IPA | ≥ 1GB |
| WebGL | Gzip HTML | ≤ 20MB |
| Windows | EXE | ≥ 500MB |

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request。请确保所有提交通过验证门禁。
