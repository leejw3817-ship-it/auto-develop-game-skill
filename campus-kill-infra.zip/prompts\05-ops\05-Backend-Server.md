---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 4c8a8bb6f995287693e182da72e4edfd_be3c0fa1891a11f1a68c525400826444
    ReservedCode1: LI6JkYmRHzYyrCB/xSD02NN1GkUd/aRAHMAaGrEdHPYp7NfqiSz7HJzffV/aJK5hXKu9adqbYuUvKh6Rb7/Gdo0SL9OgJIUdpfwr1MqPU+z9iiyJD5nKJDz0MDMlcEXxqh3C3xwitDDgJeBjGA7HPuhmvoT+uSosBu4bXpFG53U+MCZHx9PeyK668zU=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 4c8a8bb6f995287693e182da72e4edfd_be3c0fa1891a11f1a68c525400826444
    ReservedCode2: LI6JkYmRHzYyrCB/xSD02NN1GkUd/aRAHMAaGrEdHPYp7NfqiSz7HJzffV/aJK5hXKu9adqbYuUvKh6Rb7/Gdo0SL9OgJIUdpfwr1MqPU+z9iiyJD5nKJDz0MDMlcEXxqh3C3xwitDDgJeBjGA7HPuhmvoT+uSosBu4bXpFG53U+MCZHx9PeyK668zU=
---

# 05-Backend-Server 提示词

## 任务目标

搭建校园杀的游戏后端服务器。除联机对战（见 04）外，还需实现用户系统、匹配系统、排行榜、战斗日志存储、管理员后台。后端使用 Node.js + Express，数据存储使用 SQLite（零配置）。

## 输出要求

### 1. 项目结构

```
Backend/
├── package.json
├── server.js              # Express 主入口
├── routes/
│   ├── auth.js            # 注册/登录/Token 刷新
│   ├── match.js           # 匹配队列
│   ├── leaderboard.js     # 排行榜
│   ├── history.js         # 战斗历史
│   └── admin.js           # 管理员接口
├── models/
│   ├── User.js            # 用户模型
│   ├── Match.js           # 对局记录
│   └── Leaderboard.js     # 排行数据
├── middleware/
│   ├── auth.js            # JWT 验证中间件
│   └── rateLimit.js       # 限流
├── db/
│   └── init.sql           # 数据库初始化脚本
└── config.js
```

### 2. 用户系统

- 注册：用户名 + 密码（bcrypt 哈希），返回 JWT Token
- 登录：返回 Token，有效期 7 天
- 用户数据：昵称、头像 URL、胜场/败场/胜率、段位（青铜→王者）
- Token 刷新接口

### 3. 匹配系统 match.js

- 简易 ELO 匹配算法：寻找 ELO 分差 ≤200 的对手
- 匹配超时 60 秒后放宽分差到 500
- 匹配队列使用内存（不需要 Redis）
- 匹配成功自动创建房间（调用 04 的 roomManager）

### 4. 排行榜 leaderboard.js

- 全服排行榜：按胜率排序 TOP 100
- 周榜：本周胜场数 TOP 50
- 每小时更新一次（定时任务）

### 5. 战斗历史 history.js

- 每局结束后自动记录：
  - 双方玩家 ID、使用英雄、胜负结果
  - 回合数、总用时
  - 关键事件日志（JSON 格式存储）
- 支持按玩家 ID 查询最近 20 局

### 6. 管理员后台 admin.js

- 查看在线人数 / 活跃房间数
- 封禁/解封玩家
- 发送全服公告
- 查看服务器负载

### 7. 数据库表设计

```sql
CREATE TABLE users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    nickname TEXT,
    elo INTEGER DEFAULT 1000,
    wins INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE matches (
    id TEXT PRIMARY KEY,
    player1_id TEXT,
    player2_id TEXT,
    winner_id TEXT,
    rounds INTEGER,
    duration_sec INTEGER,
    hero_data TEXT,          -- JSON
    event_log TEXT,          -- JSON
    played_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## 禁止行为

- 不要使用 MongoDB 或 MySQL（必须 SQLite）
- 不要使用 Docker（直接 npm start 运行）
- 不要引入 ORM（直接用 better-sqlite3）
- 密码不要明文存储

## 验收标准

- `npm start` 一键启动
- POST /api/auth/register 能注册新用户
- GET /api/leaderboard 返回排行榜
- 对局结束后 history 表有新记录
*（内容由AI生成，仅供参考）*
