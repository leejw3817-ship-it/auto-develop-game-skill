# Campus Kill Infra - 手游全自动基础架构搭建技能

## 概述

为卡牌对战手游项目提供**一键式全自动基础架构搭建**。覆盖三大游戏引擎、三大UI引擎、全栈运维体系、CI/CD流水线、分类库配置、验证门禁的全链路自动化脚手架。

适用场景：从零搭建一款多人在线卡牌对战手游（类似三国杀/校园杀）的完整技术栈。

## 触发词

`搭建手游架构` `手游基础架构` `游戏脚手架` `卡牌游戏全栈` `campus-kill` `校园杀搭建` `手游自动化配置`

## 架构拓扑

```
campus-kill-infra/
├── prompts/                  # AI 提示词库（32份）
│   ├── 01-engine/            # 引擎集成提示词
│   ├── 02-ui/                # UI引擎提示词
│   ├── 03-gameplay/          # 核心玩法提示词
│   ├── 04-build/             # 构建打包提示词
│   ├── 05-ops/               # 运维部署提示词
│   ├── 06-quality/           # 质量门禁提示词
│   └── 07-master/            # 整合主控提示词
├── config/                   # 手游配置体系
│   ├── card-library/         # 卡牌分类库（JSON，零依赖）
│   ├── design-tokens/        # 三引擎统一设计变量
│   └── build-profiles/       # 开发/预发布/生产三套构建配置
├── scripts/                  # 自动化脚本
│   ├── install/              # 环境安装（Python/Node/Unity验证）
│   ├── build/                # 构建脚本
│   ├── test/                 # 测试脚本
│   ├── automation/           # Chrome扩展测试/UI自动化/FairyGUI发布
│   └── ops/                  # 运维脚本
├── engine-plugins/           # 引擎插件包
│   ├── unity/                # Unity 2022.3 插件
│   └── fairygui/             # FairyGUI 插件
├── codebase/                 # 核心代码库
│   └── BuildScript.cs        # Unity 自动化构建脚本
├── verification/             # 验证门禁
│   └── verification-modal.html
└── docs/                     # 文档
```

## 核心能力

### 1. 卡牌分类库（config/card-library/）

5个零依赖JSON数据文件，驱动全部引擎：

| 文件 | 内容 | 条目数 |
|------|------|--------|
| card-types.json | 4基础+18锦囊+8装备类型定义 | 30卡牌 |
| heroes.json | 23角色（含2主公）+5阵营 | 23角色 |
| skills-taxonomy.json | 37技能完整描述 | 37技能 |
| game-rules.json | 6轮次/4身份/160牌堆规则 | 完整规则 |
| camps.json | 5阵营配置 | 5阵营 |

### 2. 三套游戏引擎

| 引擎 | 提示词文件 | 产出 |
|------|-----------|------|
| Unity 2022.3.62f3c1 | 08-Unity-DualEngine.md + 校园杀-Unity双引擎提示词.md | APK 22MB + WebGL 17MB |
| Python 3 控制台 | 03-Card-Game-Core.md | campus_kill.py (1129行) |
| H5+Capacitor | card-game-mobile-prompt.md | book-to-skill-1.2.0 APK |

### 3. 三套UI引擎

| 引擎 | 提示词文件 | 组件 |
|------|-----------|------|
| FairyGUI | 01-FairyGUI-Integration.md + FairyGUI-Claude自动操作提示词.md | 6包51组件 |
| UGUI Canvas 2D | 校园杀-Unity资源与渲染提示词.md | 原生Unity UI |
| HTML+CSS | 校园杀-UI资源与设计提示词.md | Web UI |

### 4. 全自动安装脚本

- `install-python-deps.ps1` - Python依赖一键安装
- `install-node-deps.ps1` - Node.js全栈环境
- `install-ops-monitoring.ps1` - Docker+ELK+Grafana+Prometheus
- `verify-unity-modules.ps1` - Unity模块完整性验证
- `install-all.bat` - 总调度脚本

### 5. 运维引擎（CampusKillOps）

- GitHub Actions CI/CD
- Docker 容器化部署
- ELK 日志分析
- Grafana 可视化监控
- Loki 日志聚合
- Prometheus 指标采集

## 使用方式

### 一键搭建

```
@Marvis 帮我搭建手游基础架构，目标平台 Android+iOS+WebGL
```

Claude 将按以下顺序执行：
1. 扫描 config/card-library/ 加载分类数据
2. 按 prompts/ 分类加载对应提示词
3. 执行 scripts/install/ 安装依赖
4. 生成引擎代码框架
5. 配置构建流水线
6. 启动验证门禁

### 分步使用

**仅搭建卡牌分类库：**
```
@Marvis 加载 config/card-library/ 的分类数据，生成 Unity 侧的 CardData.cs
```

**仅配置运维体系：**
```
@Marvis 根据 prompts/05-ops/ 的提示词，部署 Docker 监控栈
```

## 依赖要求

| 组件 | 版本要求 |
|------|---------|
| Python | 3.11+ |
| Node.js | 24+ |
| Unity | 2022.3.62f3c1 (Android+WebGL模块) |
| Docker Desktop | 最新稳定版 |
| Git | 2.55+ |
| FairyGUI Editor | 最新版 |

## 质量标准

- 手游 APK ≥ 1GB（含资源包）
- WebGL 构建 ≤ 20MB（压缩后）
- 卡牌分类库零外部依赖，纯JSON驱动
- 所有提示词内置验证门禁（verification-modal.html）
- CI/CD 流水线从 push 到构建完成 ≤ 10分钟
