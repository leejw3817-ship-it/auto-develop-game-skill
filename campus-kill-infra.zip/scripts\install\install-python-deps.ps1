# ============================================================
# 校园杀 · Python 依赖自动安装脚本
# 功能：安装 pytest、book-to-skill 及相关工具
# ============================================================

Write-Host "=== 校园杀 Python 依赖安装 ===" -ForegroundColor Cyan
Write-Host ""

# 检查 Python
$pyVer = python --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[错误] Python 未安装，请从 https://www.python.org/downloads/ 下载安装" -ForegroundColor Red
    exit 1
}
Write-Host "[OK] $pyVer" -ForegroundColor Green

# 升级 pip
Write-Host ">>> 升级 pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip --quiet 2>&1 | Out-Null

# 安装 pytest
Write-Host ">>> 安装 pytest..." -ForegroundColor Yellow
python -m pip install pytest pytest-cov --quiet
if ($LASTEXITCODE -eq 0) {
    $pytestVer = python -m pytest --version 2>&1
    Write-Host "[OK] $pytestVer" -ForegroundColor Green
} else {
    Write-Host "[失败] pytest 安装失败" -ForegroundColor Red
}

# 安装 book-to-skill
Write-Host ">>> 安装 book-to-skill（从本地源码）..." -ForegroundColor Yellow
$btsDir = "C:\Users\31184\Desktop\校园杀v0.1\book-to-skill-1.2.0"
if (Test-Path $btsDir) {
    Push-Location $btsDir
    python -m pip install -e . --quiet 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[OK] book-to-skill 已安装（开发模式）" -ForegroundColor Green
    } else {
        Write-Host "[警告] book-to-skill 安装失败，可稍后手动安装" -ForegroundColor Yellow
    }
    Pop-Location
} else {
    Write-Host "[跳过] book-to-skill 目录不存在" -ForegroundColor Yellow
}

# 额外工具
Write-Host ">>> 安装辅助工具（requests, rich）..." -ForegroundColor Yellow
python -m pip install requests rich --quiet 2>&1 | Out-Null
Write-Host "[OK] requests, rich 已安装" -ForegroundColor Green

Write-Host ""
Write-Host "=== Python 依赖安装完成 ===" -ForegroundColor Cyan
