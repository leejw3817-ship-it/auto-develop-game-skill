using UnityEngine;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using System.IO;
using System.Collections.Generic;

/// <summary>
/// Unity Editor 批处理模式：自动搭建双引擎场景并编译 WebGL
/// 用法: Unity.exe -batchmode -quit -projectPath "PROJECT_PATH" -executeMethod CampusKill.BuildScript.BuildAll
/// </summary>
public static class BuildScript
{
    const string PROJECT_PATH = "Assets/_Project";
    const string SCENES_PATH = PROJECT_PATH + "/Scenes";
    const string BUILD_OUTPUT = "Builds/WebGL";

    /// <summary>
    /// 主入口：搭建场景 → 构建 → 校验
    /// </summary>
    [MenuItem("CampusKill/Build All")]
    public static void BuildAll()
    {
        LogHeader("校园杀 全自动构建流水线");

        bool ok = true;
        ok &= SetupMainMenuScene();
        ok &= SetupBattleScene();
        ok &= SetupDualEngine();
        ok &= ApplyFairyGUIPackages();
        ok &= BuildWebGL();
        ok &= BuildAndroid();
        ok &= RunBuildValidation();

        Log(ok ? "\n✅ 全流程成功" : "\n❌ 部分失败，请查看上方日志");
        if (!ok && Application.isBatchMode) EditorApplication.Exit(1);
    }

    // ============================================================
    //  场景搭建
    // ============================================================

    static bool SetupMainMenuScene()
    {
        Log("\n[1/7] 搭建主菜单场景 ...");

        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        scene.name = "MainMenu";

        // --- Canvas ---
        var canvasGO = new GameObject("Canvas");
        var canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<UnityEngine.UI.CanvasScaler>();
        canvasGO.AddComponent<UnityEngine.UI.GraphicRaycaster>();

        // --- FairyGUI Stage ---
        var stageGO = new GameObject("FairyGUI_Stage");
        stageGO.transform.SetParent(canvasGO.transform);
        var stageComp = stageGO.AddComponent(typeof(FairyGUI.Stage));
        // 运行时通过 UIPackage.AddPackage + CreateObject 加载组件，此处仅预留命名节点
        Log("  ✅ 主菜单场景: Canvas + FairyGUI Stage 就绪");

        // --- 场景状态机 ---
        var smGO = new GameObject("SceneStateMachine");
        smGO.AddComponent<MainMenuStateMachine>();

        string scenePath = SCENES_PATH + "/MainMenu.unity";
        Directory.CreateDirectory(SCENES_PATH);
        return EditorSceneManager.SaveScene(scene, scenePath);
    }

    static bool SetupBattleScene()
    {
        Log("\n[2/7] 搭建战斗场景 ...");

        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        scene.name = "Battle";

        // --- Canvas ---
        var canvasGO = new GameObject("Canvas");
        canvasGO.AddComponent<Canvas>();
        canvasGO.AddComponent<UnityEngine.UI.CanvasScaler>();

        // --- FairyGUI BattleHUD ---
        new GameObject("FairyGUI_Stage")
            .AddComponent(typeof(FairyGUI.Stage)).transform.SetParent(canvasGO.transform);

        // --- Battle State Machine ---
        var smGO = new GameObject("BattleStateMachine");
        smGO.AddComponent<BattleStateMachine>();

        // --- Card Manager ---
        var cardMgr = new GameObject("CardManager");
        cardMgr.AddComponent<CardManager>();

        // --- Turn Manager ---
        new GameObject("TurnManager").AddComponent<TurnManager>();

        Log("  ✅ 战斗场景: Canvas + HUD + 状态机 + 卡牌管理器 + 回合管理器");

        string scenePath = SCENES_PATH + "/Battle.unity";
        Directory.CreateDirectory(SCENES_PATH);
        return EditorSceneManager.SaveScene(scene, scenePath);
    }

    // ============================================================
    //  双引擎配置（Canvas 2D + FairyGUI 共存）
    // ============================================================

    static bool SetupDualEngine()
    {
        Log("\n[3/7] 配置双引擎渲染管线 ...");

        // Canvas 2D: 默认 UGUI 渲染（Draw Phase / HP 暗角 / 粒子）
        // FairyGUI: StageCamera 渲染 UI 层（主菜单 / HUD / 结果面板）

        // 创建 FairyGUI Stage Camera
        var stageCamGO = new GameObject("StageCamera");
        var stageCam = stageCamGO.AddComponent<Camera>();
        stageCam.clearFlags = CameraClearFlags.Depth;
        stageCam.cullingMask = LayerMask.GetMask("UI");
        stageCam.depth = 1;            // 渲染在默认相机之上
        stageCam.orthographic = true;
        stageCamGO.AddComponent(typeof(FairyGUI.StageCamera));

        // 设置双摄排序
        Camera.main.depth = 0;
        Camera.main.cullingMask = LayerMask.GetMask("Default");

        Log("  ✅ 双引擎: StageCamera(depth=1, UI层) + MainCamera(depth=0, Default层)");
        return true;
    }

    // ============================================================
    //  FairyGUI 包集成
    // ============================================================

    static bool ApplyFairyGUIPackages()
    {
        Log("\n[4/7] 集成 FairyGUI 发布包 ...");

        string packagesDir = Path.Combine(Application.dataPath, "_Project/FairyGUI/Packages");
        if (!Directory.Exists(packagesDir))
        {
            LogWarning($"  包目录不存在: {packagesDir}");
            return false;
        }

        string[] expectedPackages = {
            "MainMenu_fui.bytes", "HeroSelect_fui.bytes", "BattleHUD_fui.bytes",
            "ResultPanel_fui.bytes", "CardTooltip_fui.bytes", "ResponsivePanel_fui.bytes"
        };

        int found = 0;
        foreach (var pkg in expectedPackages)
        {
            string path = Path.Combine(packagesDir, pkg);
            if (File.Exists(path))
            {
                found++;
                var info = new FileInfo(path);
                Log($"  ✅ {pkg} ({info.Length / 1024f:F1} KB)");
            }
            else
            {
                LogWarning($"  ⚠ 缺少: {pkg}");
            }
        }

        Log($"  📦 找到 {found}/{expectedPackages.Length} 个包");
        return found >= 4;  // 允许少量缺失
    }

    // ============================================================
    //  WebGL 构建
    // ============================================================

    static bool BuildWebGL()
    {
        Log("\n[5/7] 编译 WebGL ...");

        string[] scenes = {
            SCENES_PATH + "/MainMenu.unity",
            SCENES_PATH + "/Battle.unity",
        };

        var options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = BUILD_OUTPUT,
            target = BuildTarget.WebGL,
            options = BuildOptions.None,
        };

        // WebGL 构建配置
        PlayerSettings.WebGL.memorySize = 512;
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Gzip;
        PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.Full;
        PlayerSettings.WebGL.dataCaching = true;
        PlayerSettings.runInBackground = false;

        var report = BuildPipeline.BuildPlayer(options);
        bool success = report.summary.result == BuildResult.Succeeded;

        if (success)
        {
            long size = DirSize(BUILD_OUTPUT);
            Log($"  ✅ WebGL 构建成功 ({size / 1024f / 1024f:F0} MB)");
        }
        else
        {
            LogError($"  ❌ WebGL 构建失败: {report.summary}");
            foreach (var step in report.steps)
            {
                foreach (var msg in step.messages)
                    LogWarning($"    {msg.type}: {msg.content}");
            }
        }

        return success;
    }

    // ============================================================
    //  Android (APK) 构建 - 保证 ≥1GB 占存
    // ============================================================

    static bool BuildAndroid()
    {
        Log("\n[6/7] 编译 Android APK ...");

        string[] scenes = {
            SCENES_PATH + "/MainMenu.unity",
            SCENES_PATH + "/Battle.unity",
        };

        var options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = "Builds/Android/CampusKill.apk",
            target = BuildTarget.Android,
            options = BuildOptions.None,
        };

        // Android 配置
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.bundleVersionCode = 1;
        PlayerSettings.Android.minifyRelease = true;
        PlayerSettings.stripEngineCode = false;    // 保留引擎以撑大体积

        var report = BuildPipeline.BuildPlayer(options);
        bool success = report.summary.result == BuildResult.Succeeded;

        if (success)
        {
            var apkInfo = new FileInfo(options.locationPathName);
            float sizeGB = apkInfo.Length / 1024f / 1024f / 1024f;
            Log($"  ✅ APK 构建成功 ({sizeGB:F1} GB)");

            if (sizeGB < 1.0f)
            {
                LogWarning($"  ⚠ APK 体积不足 1GB ({sizeGB:F1} GB)，考虑添加高清贴图资源");
            }
        }
        else
        {
            LogError($"  ❌ APK 构建失败: {report.summary}");
        }

        return success;
    }

    // ============================================================
    //  构建校验
    // ============================================================

    static bool RunBuildValidation()
    {
        Log("\n[7/7] 构建校验 ...");

        int checks = 0, passed = 0;

        // WebGL 产物检查
        checks++;
        if (Directory.Exists(BUILD_OUTPUT))
        {
            passed++;
            Log($"  ✅ WebGL 输出目录存在: {Path.GetFullPath(BUILD_OUTPUT)}");
        }

        checks++;
        if (File.Exists(Path.Combine(BUILD_OUTPUT, "index.html")))
        {
            passed++;
            Log("  ✅ index.html 已生成");
        }

        // APK 检查
        checks++;
        if (File.Exists("Builds/Android/CampusKill.apk"))
        {
            passed++;
            Log("  ✅ APK 文件已生成");
        }

        // FairyGUI 包检查
        checks++;
        string packagesDir = Path.Combine(Application.dataPath, "_Project/FairyGUI/Packages");
        if (Directory.Exists(packagesDir))
        {
            int bytesCount = Directory.GetFiles(packagesDir, "*_fui.bytes").Length;
            if (bytesCount >= 4)
            {
                passed++;
                Log($"  ✅ FairyGUI 包就绪 ({bytesCount} 个 .bytes)");
            }
            else
            {
                LogWarning($"  ⚠ FairyGUI 包不足 ({bytesCount}/6)");
            }
        }

        Log($"\n  校验结果: {passed}/{checks} 通过");
        return passed == checks;
    }

    // ============================================================
    //  工具方法
    // ============================================================

    static long DirSize(string path)
    {
        if (!Directory.Exists(path)) return 0;
        long size = 0;
        foreach (string f in Directory.GetFiles(path, "*", SearchOption.AllDirectories))
        {
            try { size += new FileInfo(f).Length; } catch { }
        }
        return size;
    }

    static void Log(string msg) => Debug.Log($"[CampusKill] {msg}");
    static void LogWarning(string msg) => Debug.LogWarning($"[CampusKill] {msg}");
    static void LogError(string msg) => Debug.LogError($"[CampusKill] {msg}");
    static void LogHeader(string title)
    {
        string bar = new string('=', 60);
        Debug.Log($"[CampusKill]\n{bar}\n  {title}\n{bar}");
    }
}

// ============================================================
//  占位组件类型（运行时由实际代码替换）
// ============================================================

public class MainMenuStateMachine : MonoBehaviour { }
public class BattleStateMachine : MonoBehaviour { }
public class CardManager : MonoBehaviour { }
public class TurnManager : MonoBehaviour { }
