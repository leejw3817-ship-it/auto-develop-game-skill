---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 4c8a8bb6f995287693e182da72e4edfd_74058fff896311f1b66e525400e6dd8f
    ReservedCode1: 3gHsU5yyEHXJ9rL5EJ0QYx/Ps/8W2CLVMS3LdsSx2lY4T1ZIzldOee0isttxd0PD60TbTk0MGU7Q/X/5iCeAWac2UqzX5cpD+wKnF7tjKXthbh39HZxWIsvQ6fCVG4aU7xWM0NRz7kbLmP/YAyIAjFIzQ+zm9URMlIMaiulQqTH0yXoKT8hAKq1RE7g=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 4c8a8bb6f995287693e182da72e4edfd_74058fff896311f1b66e525400e6dd8f
    ReservedCode2: 3gHsU5yyEHXJ9rL5EJ0QYx/Ps/8W2CLVMS3LdsSx2lY4T1ZIzldOee0isttxd0PD60TbTk0MGU7Q/X/5iCeAWac2UqzX5cpD+wKnF7tjKXthbh39HZxWIsvQ6fCVG4aU7xWM0NRz7kbLmP/YAyIAjFIzQ+zm9URMlIMaiulQqTH0yXoKT8hAKq1RE7g=
---

# 校园杀 v0.2 - 运维引擎：监控、热更新与自主部署提示词

## 项目背景

校园杀已具备双端构建能力。本提示词负责搭建完整的运维引擎体系——独立运维库、实时监控、热更新、自主部署，实现游戏上线后的持续运营能力。

项目根路径：`C:\CampusKillUnity`

## 核心约束

1. **独立运维库**：所有运维代码放入独立文件夹 `Assets/_Project/Plugins/CampusKillOps/`，编译为独立 `.asmdef` 程序集，与游戏逻辑解耦。
2. **零外部付费 SaaS**：监控/日志/热更新均基于开源方案自建，不依赖 Firebase/Crashlytics 等付费平台。
3. **自主选型**：每个技术选型需列出至少 2 个候选方案并说明选择理由。
4. **低侵入**：运维代码通过事件/接口与游戏逻辑交互，不直接修改游戏代码。

---

## 子系统一：日志与异常捕获

### 独立运维库结构
```
Assets/_Project/Plugins/CampusKillOps/
├── CampusKillOps.asmdef          # 独立程序集定义
├── Logging/
│   ├── OpsLogger.cs              # 统一日志接口
│   ├── LogLevel.cs               # 日志级别枚举
│   ├── LogTransporter.cs         # 日志传输层（本地文件 + 远程上报）
│   └── LogRingBuffer.cs          # 环形缓冲区（内存 64MB，崩溃前日志不丢）
├── Crash/
│   ├── CrashCatcher.cs           # Unity 崩溃捕获（Application.logMessageReceived）
│   ├── CrashDumpFormatter.cs     # 崩溃堆栈格式化（含设备信息、场景名、帧号）
│   └── CrashUploader.cs          # 崩溃报告上传
├── Monitoring/
│   ├── FPSMonitor.cs             # 帧率实时监控
│   ├── MemoryMonitor.cs          # 内存水位监控（Mono + Native + Graphics）
│   ├── NetworkMonitor.cs         # 网络延迟/丢包/重连监控
│   └── DeviceInfoCollector.cs    # 设备信息采集（OS/GPU/RAM/屏幕）
└── HotUpdate/
    ├── HotUpdateManager.cs       # 热更新管理器
    ├── AssetBundlePatcher.cs     # AB 包差异更新
    ├── VersionChecker.cs         # 版本比对
    └── CDNDownloader.cs          # CDN 下载器（断点续传 + 校验）
```

### 日志系统要求
1. **多级别**：Verbose / Debug / Info / Warning / Error / Fatal，通过运行时开关动态切换。
2. **双通道**：本地文件（`Application.persistentDataPath/logs/`）+ 远程上报（HTTP POST 到自建日志收集服务）。
3. **环形缓冲**：内存中保留最近 64MB 日志，崩溃时自动刷盘，确保崩溃前日志不丢失。
4. **标签系统**：每条日志携带 `[标签]`（如 `[Battle]`、`[Network]`、`[AI]`），支持按标签过滤。
5. **性能保护**：日志写入异步队列，不阻塞主线程；每秒日志上限 1000 条，超出自动降级采样。

### 崩溃捕获要求
1. 捕获所有未处理异常（`Application.logMessageReceived` + `AppDomain.CurrentDomain.UnhandledException`）。
2. 崩溃报告包含：堆栈、设备型号、OS 版本、GPU、RAM 总量/可用、当前场景、帧号、最近 100 条日志。
3. 上报到自建 HTTP 端点 `POST /api/crash-report`，JSON 格式，可选 gzip 压缩。

---

## 子系统二：性能监控看板

### 技术选型

| 方案 | 优点 | 缺点 | 选择 |
|------|------|------|------|
| ELK Stack (Elasticsearch + Logstash + Kibana) | 成熟、可视化强 | 部署重、资源消耗大 | ✅ 生产环境 |
| Grafana + Loki + Promtail | 轻量、Grafana 生态 | 配置复杂 | 备选 |
| 自建 SQLite + ECharts Web | 零依赖 | 功能弱 | 仅开发阶段 |

### 监控指标
1. **FPS 分布**：P50 / P95 / P99 帧率，按场景分别统计。
2. **内存水位**：Mono Heap / Native / Graphics / Total，每 30 秒采样一次。
3. **崩溃率**：崩溃次数 / 启动次数，按版本号分组。
4. **网络质量**：平均 RTT、丢包率、重连次数。
5. **APK 冷启动时间**：从进程创建到首帧渲染。

### 看板实现
1. 使用 ECharts（https://echarts.apache.org）在 `Builds/WebGL/dashboard/` 下生成监控看板 HTML，读取 JSON 数据文件渲染折线图/饼图/热力图。
2. Unity 端每 30 秒将性能采样写入 `monitor_data.json`。
3. 开发阶段：监控看板作为 WebGL 构建的子页面，通过 `window.open` 打开。
4. 生产阶段：数据上报到 ELK，通过 Kibana 查看。

---

## 子系统三：热更新系统

### 技术选型

| 方案 | 优点 | 缺点 | 选择 |
|------|------|------|------|
| AssetBundle + 版本号比对 | Unity 原生、稳定 | 包体管理复杂 | ✅ 当前选型 |
| Addressables（Unity 官方） | 自动化管理 | 依赖 Unity 服务 | 备选（项目已安装） |
| HybridCLR（huatuo） | 支持 C# 热更 | 需要 IL2CPP、配置复杂 | 后续考虑 |

### 实现要求
1. **版本定义**：`major.minor.patch.build`，例 `0.2.1.20260727`。
2. **资源版本清单**：构建时生成 `asset_manifest.json`，记录每个 AssetBundle 的 MD5 + 大小 + 版本号。
3. **差异下载**：比对本地与远程清单，仅下载变化的 AB 包，支持断点续传。
4. **CDN 分发**：AB 包上传到对象存储（阿里云 OSS / MinIO 自建），通过 CDN 加速下载。
5. **静默更新**：后台下载新版本资源，下次启动时自动应用，不打断当前游戏。
6. **回滚机制**：保留上一版本资源，若新版本启动 3 次均崩溃，自动回退。

### 代码框架
```csharp
public class HotUpdateManager : MonoBehaviour
{
    public string cdnBaseUrl = "https://cdn.campuskill.example.com/";
    public string currentVersion = "0.2.0.0";
    
    async Task<bool> CheckAndUpdate()
    {
        // 1. 获取远程 manifest
        // 2. 比对本地 manifest
        // 3. 下载差异包（断点续传）
        // 4. 校验 MD5
        // 5. 标记待应用
    }
}
```

---

## 子系统四：自主部署脚本

### 一键部署脚本 `deploy.ps1`

```powershell
# deploy.ps1 - 校园杀一键部署
param(
    [string]$Environment = "staging",  # staging / production
    [string]$OssBucket = "campuskill-builds",
    [string]$OssEndpoint = "https://oss-cn-hangzhou.aliyuncs.com"
)

$projectRoot = "C:\CampusKillUnity"
$buildDir = "$projectRoot\Builds"
$version = (Get-Date -Format "yyyy.M.d.HHmm")
$tag = "$Environment-$version"

Write-Host "=== 校园杀部署流水线 $tag ==="

# Step 1: 构建
Write-Host "[1/5] 构建..."
& "$projectRoot\ci-build.ps1"

# Step 2: 版本标记
Write-Host "[2/5] 版本标记: $tag"
$versionJson = @{ version = $version; env = $Environment; timestamp = (Get-Date -Format "o") }
$versionJson | ConvertTo-Json | Out-File "$buildDir\version.json"

# Step 3: 上传 CDN（WebGL）
Write-Host "[3/5] 上传 WebGL 到 OSS..."
# 使用 ossutil 命令行工具
ossutil cp -r "$buildDir\WebGL" "oss://$OssBucket/webgl/$version/" --endpoint $OssEndpoint

# Step 4: 上传 APK
Write-Host "[4/5] 上传 APK..."
ossutil cp "$buildDir\Android\CampusKill.apk" "oss://$OssBucket/android/$version/CampusKill.apk" --endpoint $OssEndpoint

# Step 5: 生成部署报告
Write-Host "[5/5] 生成部署报告..."
@"
# 校园杀部署报告
- 环境: $Environment
- 版本: $version
- WebGL: https://cdn.campuskill.example.com/webgl/$version/
- APK: https://cdn.campuskill.example.com/android/$version/CampusKill.apk
- 时间: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
"@ | Out-File "$buildDir\deploy-report-$tag.md"

Write-Host "部署完成: $tag"
```

### MinIO 自建对象存储（无外部依赖备选）

若无法使用阿里云 OSS，使用 MinIO Docker 自建：
```bash
docker run -d --name minio -p 9000:9000 -p 9001:9001 \
  -v C:\minio-data:/data \
  minio/minio server /data --console-address ":9001"
```

---

## 交付验证

完成后在 `C:\CampusKillUnity\Builds\` 生成：

1. **`ops-report.json`**：
```json
{
  "logging": {"ring_buffer_mb": 64, "log_channels": ["file", "remote"]},
  "crash_catcher": {"hooked": true, "test_crash_reported": false},
  "monitoring": {"fps_collector": true, "memory_collector": true, "network_collector": true},
  "hot_update": {"manifest_generated": false, "cdn_uploaded": false},
  "deploy_script": "deploy.ps1"
}
```

2. **`ops-verification-modal.html`**：弹窗验证，逐项勾选日志/崩溃/监控/热更新/部署 5 个子系统。
*（内容由AI生成，仅供参考）*
