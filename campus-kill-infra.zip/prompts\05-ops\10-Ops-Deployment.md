---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 4c8a8bb6f995287693e182da72e4edfd_c32bb2d5891a11f1b66e525400e6dd8f
    ReservedCode1: 7A8jD/39eMApHU7H7i2et8mgangnf23f5zP57aMqK3SmR5NcT6lh+Xqj11KJLUQxLCDyC7iFW8FtRVMjPyEFm3gJscTjpaZKMvmbs8+Peh+kT9C1kNCEFOtUGSZQqbMjjMSWjU0pdA4llCk2g56U/EA0zTVptz/DBOC0sAbj+V4y+YqGuQmAO6NPozk=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 4c8a8bb6f995287693e182da72e4edfd_c32bb2d5891a11f1b66e525400e6dd8f
    ReservedCode2: 7A8jD/39eMApHU7H7i2et8mgangnf23f5zP57aMqK3SmR5NcT6lh+Xqj11KJLUQxLCDyC7iFW8FtRVMjPyEFm3gJscTjpaZKMvmbs8+Peh+kT9C1kNCEFOtUGSZQqbMjjMSWjU0pdA4llCk2g56U/EA0zTVptz/DBOC0sAbj+V4y+YqGuQmAO6NPozk=
---

# 10-Ops-Deployment 提示词

## 任务目标

自主选择最优的运维引擎，搭建校园杀的持续集成、自动部署、监控告警、灰度发布体系。要求独立库搭建，不侵入游戏代码。

## 输出要求

### 1. 运维引擎选型

推荐使用以下技术栈（给出选型理由）：

| 组件 | 选型 | 理由 |
|------|------|------|
| CI/CD | GitHub Actions | 免费、与代码仓库一体、社区 Actions 丰富 |
| 容器化 | Docker Compose | 轻量、单机即可运行、配置简单 |
| 反向代理 | Nginx | 高性能、支持 WebSocket 代理、免费 |
| 监控 | Prometheus + Grafana | 行业标准、可视化强大、告警规则灵活 |
| 日志 | Loki + Promtail | 与 Grafana 集成、轻量、无需 Elasticsearch |
| 进程管理 | PM2 | Node.js 进程守护、自动重启、负载均衡 |
| 证书 | Let's Encrypt + Certbot | 免费 HTTPS 证书、自动续期 |

备选：如果服务器性能不足（<2GB RAM），降级为：
- PM2（进程管理）+ SQLite（单文件数据库）+ Caddy（自动 HTTPS）+ 简单的 health check 端点

### 2. 项目结构

```
Ops/
├── docker-compose.yml        # 全部服务编排
├── nginx/
│   ├── nginx.conf             # 反向代理配置（含 WebSocket 升级）
│   └── sites-enabled/
│       └── campuskill.conf
├── prometheus/
│   ├── prometheus.yml         # 抓取配置
│   └── rules/
│       └── alerts.yml         # 告警规则
├── grafana/
│   └── dashboards/
│       ├── game-overview.json        # 游戏总览（在线人数、房间数、对局数）
│       └── server-health.json        # 服务器健康（CPU/内存/网络/磁盘）
├── scripts/
│   ├── deploy.sh              # 一键部署脚本
│   ├── backup.sh              # 数据库定时备份
│   ├── healthcheck.sh         # 健康检查（Docker HEALTHCHECK）
│   └── rollback.sh            # 回滚脚本
├── pm2/
│   └── ecosystem.config.js    # PM2 配置（Node.js 服务集群）
└── Makefile                   # 快捷命令
```

### 3. docker-compose.yml 核心服务

```yaml
services:
  nginx:
    image: nginx:alpine
    ports: ["80:80", "443:443"]
    volumes: [./nginx/nginx.conf:/etc/nginx/nginx.conf]
    
  server:
    build: ../Server
    deploy:
      replicas: 2
    depends_on: []
    
  prometheus:
    image: prom/prometheus
    ports: ["9090:9090"]
    volumes: [./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml]
    
  grafana:
    image: grafana/grafana
    ports: ["3000:3000"]
    environment:
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD}
```

### 4. CI/CD Pipeline

GitHub Actions workflow `.github/workflows/deploy.yml`：

```yaml
name: Deploy CampusKill
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: cd Server && npm ci && npm test
      - run: cd Backend && npm ci && npm test
  
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: scp -r Server/ user@server:/opt/campuskill/
      - run: ssh user@server "cd /opt/campuskill/Ops && docker compose up -d --build"
```

### 5. 监控面板

#### Grafana Dashboard: Game Overview
- 实时在线人数（折线图）
- 活跃房间数（数字面板）
- 每分钟对局数（柱状图）
- 平均匹配等待时间（秒）
- 今日新注册用户数

#### Grafana Dashboard: Server Health
- CPU 使用率 / 内存使用率 / 磁盘使用率
- 网络流量（入/出）
- PM2 进程状态
- WebSocket 连接数
- API 响应时间 P50/P95/P99

### 6. 告警规则 alerts.yml

```yaml
groups:
  - name: campuskill
    rules:
      - alert: HighCPU
        expr: cpu_usage > 80
        for: 5m
        annotations:
          summary: "服务器 CPU 使用率超过 80%"
      - alert: ServerDown
        expr: up == 0
        for: 1m
        annotations:
          summary: "服务不可达"
      - alert: HighErrorRate
        expr: rate(http_errors_total[5m]) > 0.05
        for: 2m
        annotations:
          summary: "错误率超过 5%"
```

### 7. 灰度发布策略

- 金丝雀发布：新版本先部署到 1 个实例，10% 流量路由到新实例
- 观察 30 分钟（错误率/延迟无异常）
- 全量发布
- 异常时自动回滚（调用 rollback.sh）

## 部署命令

```bash
cd Ops
make deploy        # 首次部署
make update        # 更新服务
make backup        # 备份数据库
make logs          # 查看日志
make status        # 服务状态
```

## 禁止行为

- 不要使用 Kubernetes（过度工程化，单机项目不需要）
- 不要在 Docker 内运行 SQLite（数据持久化问题）
- 不要暴露监控面板到公网（Grafana 仅内网或加 IP 白名单）
- 不要忽略 HTTPS 配置

## 验收标准

- `make deploy` 一键启动所有服务
- 浏览器访问 `https://域名` 能正常游戏
- Grafana 面板能看到实时在线人数
- 模拟服务崩溃后 PM2 30 秒内自动重启
- CI 提交代码后自动测试 + 部署
*（内容由AI生成，仅供参考）*
